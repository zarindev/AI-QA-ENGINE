"""Locators recorded by QA Pilot for the Access module."""

from pages.base import BasePage, Loc


class AccessPage(BasePage):
    pass
