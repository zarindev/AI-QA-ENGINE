"""Locators recorded by QA Pilot for the Accessibility module."""

from pages.base import BasePage, Loc


class AccessibilityPage(BasePage):
    pass
