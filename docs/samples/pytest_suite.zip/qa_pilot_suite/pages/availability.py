"""Locators recorded by QA Pilot for the Availability module."""

from pages.base import BasePage, Loc


class AvailabilityPage(BasePage):
    HYUNDAI_TUCSON_A = Loc(text='Hyundai Tucson', css='div:nth-of-type(2) > table > tbody > tr:nth-of-type(9) > td:nth-of-type(1) > a', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[2]/table[1]/tbody[1]/tr[9]/td[1]/a[1]', tag='a')
    SEND_TO_MAINTENANCE_BUTTON = Loc(text='Send to maintenance', css='main > div:nth-of-type(1) > div:nth-of-type(2) > div > form > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[2]/div[1]/form[1]/button[1]', tag='button')
