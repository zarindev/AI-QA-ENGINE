"""Locators recorded by QA Pilot for the Booking module."""

from pages.base import BasePage, Loc


class BookingPage(BasePage):
    CAR_SELECT = Loc(id='car_id', name='car_id', label='Car', css='#car_id', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/select[1]', tag='select')
    CUSTOMER_SELECT = Loc(id='customer_id', name='customer_id', label='Customer', css='#customer_id', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/select[2]', tag='select')
    PICKUP_DATE_INPUT = Loc(name='pickup_date', css='main > div > form > div > div:nth-of-type(1) > input', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[1]/div[1]/input[1]', tag='input')
    RETURN_DATE_INPUT = Loc(name='return_date', css='main > div > form > div > div:nth-of-type(2) > input', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[1]/div[2]/input[1]', tag='input')
    CONFIRM_BOOKING_BUTTON = Loc(text='Confirm booking', css='div > div > main > div > form > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/button[1]', tag='button')
    HAND_OVER_CAR_BUTTON = Loc(text='Hand over car', css='main > div > div:nth-of-type(1) > div > form:nth-of-type(1) > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/form[1]/button[1]', tag='button')
    B_0006_A = Loc(text='B-0006', css='div:nth-of-type(2) > table > tbody > tr:nth-of-type(2) > td:nth-of-type(1) > a', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[2]/table[1]/tbody[1]/tr[2]/td[1]/a[1]', tag='a')
    B_0009_A = Loc(text='B-0009', css='div:nth-of-type(2) > table > tbody > tr:nth-of-type(6) > td:nth-of-type(1) > a', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[2]/table[1]/tbody[1]/tr[6]/td[1]/a[1]', tag='a')
    B_0008_A = Loc(text='B-0008', css='div:nth-of-type(2) > table > tbody > tr:nth-of-type(3) > td:nth-of-type(1) > a', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[2]/table[1]/tbody[1]/tr[3]/td[1]/a[1]', tag='a')
    CANCEL_BOOKING_BUTTON = Loc(text='Cancel booking', css='main > div > div:nth-of-type(1) > div > form:nth-of-type(2) > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/form[2]/button[1]', tag='button')
    HAND_OVER_CAR_BUTTON_2 = Loc(text='Hand over car', css='main > div > div:nth-of-type(1) > div > form > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/form[1]/button[1]', tag='button')
    BOOKINGS_A = Loc(text='Bookings', css='html > body > div > aside > nav > a:nth-of-type(4)', xpath='/html[1]/body[1]/div[1]/aside[1]/nav[1]/a[4]', tag='a')
    NEW_BOOKING_A = Loc(text='New booking', css='div > div > main > div:nth-of-type(2) > p > a', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[2]/p[1]/a[1]', tag='a')
