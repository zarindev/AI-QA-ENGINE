"""Locators recorded by QA Pilot for the Car module."""

from pages.base import BasePage, Loc


class CarPage(BasePage):
    MAKE_INPUT = Loc(id='make', name='make', label='Make', css='#make', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[1]/div[1]/input[1]', tag='input')
    MODEL_INPUT = Loc(id='model', name='model', label='Model', css='#model', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[1]/div[2]/input[1]', tag='input')
    PLATE_INPUT = Loc(id='plate', name='plate', label='Plate', css='#plate', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[2]/div[1]/input[1]', tag='input')
    CATEGORY_SELECT = Loc(id='category', name='category', label='Category', css='#category', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[2]/div[2]/select[1]', tag='select')
    DAILY_RATE_INPUT = Loc(id='daily_rate', name='daily_rate', label='Daily rate ($)', css='#daily_rate', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[3]/div[1]/input[1]', tag='input')
    SEATS_INPUT = Loc(id='seats', name='seats', label='Seats', css='#seats', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[3]/div[2]/input[1]', tag='input')
    SAVE_CAR_BUTTON = Loc(text='Save car', css='div > div > main > div > form > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/button[1]', tag='button')
