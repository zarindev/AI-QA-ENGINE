"""Locators recorded by QA Pilot for the Dashboard module."""

from pages.base import BasePage, Loc


class DashboardPage(BasePage):
    B_0028_A = Loc(text='B-0028', css='div:nth-of-type(2) > table > tbody > tr:nth-of-type(2) > td:nth-of-type(1) > a', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[2]/table[1]/tbody[1]/tr[2]/td[1]/a[1]', tag='a')
    CANCEL_BOOKING_BUTTON = Loc(text='Cancel booking', css='main > div > div:nth-of-type(1) > div > form:nth-of-type(2) > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/form[2]/button[1]', tag='button')
