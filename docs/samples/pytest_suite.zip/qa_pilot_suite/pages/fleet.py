"""Locators recorded by QA Pilot for the Fleet module."""

from pages.base import BasePage, Loc


class FleetPage(BasePage):
    B_0009_A = Loc(text='B-0009', css='div:nth-of-type(2) > table > tbody > tr:nth-of-type(20) > td:nth-of-type(1) > a', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[2]/table[1]/tbody[1]/tr[20]/td[1]/a[1]', tag='a')
    RETURN_CAR_BUTTON = Loc(text='Return car', css='main > div > div:nth-of-type(1) > div > form > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/form[1]/button[1]', tag='button')
    MAKE_INPUT = Loc(id='make', name='make', label='Make', css='#make', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[1]/div[1]/input[1]', tag='input')
    MODEL_INPUT = Loc(id='model', name='model', label='Model', css='#model', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[1]/div[2]/input[1]', tag='input')
    PLATE_INPUT = Loc(id='plate', name='plate', label='Plate', css='#plate', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[2]/div[1]/input[1]', tag='input')
    DAILY_RATE_INPUT = Loc(id='daily_rate', name='daily_rate', label='Daily rate ($)', css='#daily_rate', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[3]/div[1]/input[1]', tag='input')
    SAVE_CAR_BUTTON = Loc(text='Save car', css='div > div > main > div > form > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/button[1]', tag='button')
    QAP_MAKE_QAP_MODEL_A = Loc(text='QAP_Make QAP_Model', css='div:nth-of-type(2) > table > tbody > tr:nth-of-type(14) > td:nth-of-type(1) > a', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[2]/table[1]/tbody[1]/tr[14]/td[1]/a[1]', tag='a')
    SEND_TO_MAINTENANCE_BUTTON = Loc(text='Send to maintenance', css='main > div:nth-of-type(1) > div:nth-of-type(2) > div > form > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[2]/div[1]/form[1]/button[1]', tag='button')
    SEATS_INPUT = Loc(id='seats', name='seats', label='Seats', css='#seats', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/form[1]/div[3]/div[2]/input[1]', tag='input')
