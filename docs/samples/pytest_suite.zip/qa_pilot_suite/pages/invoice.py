"""Locators recorded by QA Pilot for the Invoice module."""

from pages.base import BasePage, Loc


class InvoicePage(BasePage):
    RECORD_PAYMENT_BUTTON = Loc(text='Record payment', css='table > tbody > tr:nth-of-type(3) > td:nth-of-type(9) > form > button', xpath='/html[1]/body[1]/div[1]/div[1]/main[1]/table[1]/tbody[1]/tr[3]/td[9]/form[1]/button[1]', tag='button')
