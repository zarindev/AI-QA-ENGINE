"""Locators recorded by QA Pilot for the Revenue module."""

from pages.base import BasePage, Loc


class RevenuePage(BasePage):
    pass
