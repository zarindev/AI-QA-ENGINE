"""Locators recorded by QA Pilot for the Smoke module."""

from pages.base import BasePage, Loc


class SmokePage(BasePage):
    pass
