"""Locators recorded by QA Pilot for the UI module."""

from pages.base import BasePage, Loc


class UiPage(BasePage):
    pass
