"""Where the site lives. Override with QAP_BASE_URL or `pytest --site URL`."""

DEFAULT_BASE_URL = 'http://localhost:8102'
LOGIN_PATHS = {'admin': '/', 'agent': '/', 'customer': '/'}
